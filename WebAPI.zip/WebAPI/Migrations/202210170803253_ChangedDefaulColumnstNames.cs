namespace WebAPI.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ChangedDefaulColumnstNames : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.user", "FirstName", c => c.String());
            AddColumn("dbo.user", "LastName", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.user", "LastName");
            DropColumn("dbo.user", "FirstName");
        }
    }
}
