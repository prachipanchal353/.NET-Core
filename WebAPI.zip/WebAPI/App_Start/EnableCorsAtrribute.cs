﻿using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Cors;
using System.Web.Http.Cors;

namespace WebAPI
{
    internal class EnableCorsAtrribute : ICorsPolicyProvider
    {
        private string v;
        private string headers;
        private string methods;

        public EnableCorsAtrribute(string v, string headers, string methods)
        {
            this.v = v;
            this.headers = headers;
            this.methods = methods;
        }

        public Task<CorsPolicy> GetCorsPolicyAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            throw new System.NotImplementedException();
        }
    }
}